# Manjunadh — updated portfolio

## Run locally

1. Open this folder in VS Code.
2. Start the **Live Server** extension on `index.html` (recommended), or run a local static server from this directory.
3. Keep `videos/hero.mp4` and `videos/hero-poster.jpg` in the `videos` folder. The hero video is paused; scrolling scrubs through its frames.
4. The Resume links open `Manjunadh_Resume.html`.

The site uses Google Fonts and a few existing CDN-hosted libraries, so an internet connection is needed for those external resources. All original portfolio sections and interactions are retained, with the featured project cards and case-study data updated to match the uploaded resume.
